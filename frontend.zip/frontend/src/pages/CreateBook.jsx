import React from 'react'

const CreateBook = () => {
  return (
    <div>CreateBook</div>
  )
}

export default CreateBook