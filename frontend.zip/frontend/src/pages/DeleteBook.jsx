import React from 'react'

const DeleteBook = () => {
  return (
    <div>DeleteBook</div>
  )
}

export default DeleteBook